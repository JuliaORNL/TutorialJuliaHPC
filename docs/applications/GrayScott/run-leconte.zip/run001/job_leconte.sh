mpirun -n 1 julia --project=$GS_DIR $GS_DIR/gray-scott.jl settings-files.json | tee run.log
